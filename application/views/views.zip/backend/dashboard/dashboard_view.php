<?php defined('BASEPATH') OR exit('No direct script access allowed');?>


  
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Dashboard
            <small>Control Panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Control Panel</li>
          </ol>
          <?php echo $setting[0]['site_name'];?>
        </section>

        <!-- Main content -->
        <section class="content">
		<h1></h1>
  
          <!-- Your Page Content Here -->

        </section><!-- /.content -->
      </div>