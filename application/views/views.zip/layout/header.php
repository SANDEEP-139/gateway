<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->

<head>
	<title><?php echo $setting[0]['title'];?></title>

	<!-- Meta -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	<!-- Favicon -->
	<link rel="shortcut icon" href="<?php echo $this->Webmodel->getLogo();?>">

	<!-- Web Fonts -->
	<link rel='stylesheet' type='text/css' href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin'>

	<!-- CSS Global Compulsory -->
	<link rel="stylesheet" href="<?php echo base_url('assets/frontend/plugins/bootstrap/css/bootstrap.min.css');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/style.css');?>">

	<!-- CSS Header and Footer -->
	<link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/headers/header-v4.css');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/footers/footer-v1.css');?>">

	<!-- CSS Implementing Plugins -->
	<link rel="stylesheet" href="<?php echo base_url('assets/frontend/plugins/animate.css');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/frontend/plugins/line-icons/line-icons.css');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/frontend/plugins/font-awesome/css/font-awesome.min.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/frontend/plugins/fancybox/source/jquery.fancybox.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/frontend/plugins/cube-portfolio/cubeportfolio/css/cubeportfolio.min.css');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/frontend/plugins/cube-portfolio/cubeportfolio/custom/custom-cubeportfolio.css');?>">

	<!-- CSS Page Style -->
	<link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/pages/blog_magazine.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/pages/portfolio-v1.css');?>">

	<!-- CSS Theme -->
	<link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/theme-colors/blue.css');?>" id="style_color">
	<link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/theme-skins/dark.css');?>">

	<!-- CSS Customization -->
	<link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/custom.css');?>">
</head>

<body>
	<div class="wrapper">
		<!--=== Header v4 ===-->
		<div class="header-v4">
			<!-- Topbar -->
			<div class="topbar-v1">
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<ul class="list-inline top-v1-contacts">
								<li>
									<i class="fa fa-envelope"></i> <a href="mailto:<?php echo $setting[0]['email'];?>"><?php echo $setting[0]['email'];?></a>
								</li>
								<li>
									<i class="fa fa-phone"></i> <?php echo $setting[0]['phone'];?>
								</li>
							</ul>
						</div>

						<div class="col-md-6">
							<ul class="list-inline top-v1-data">
								<li><a href="<?php echo base_url();?>"><i class="fa fa-home"></i></a></li>
								<li><a href="https://www.facebook.com/ambedkartv" target="_blank"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#">Join us</a></li>
								<li><a href="#">My Account</a></li>
							</ul>
                          
						</div>
					</div>
				</div>
			</div>
			<!-- End Topbar -->

			<!-- Navbar -->
			<div class="navbar navbar-default mega-menu" role="navigation">
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<div class="row">
							<!--<div class="col-md-1">
								<a class="navbar-brand" href="index.html">
									<img id="logo-header" src="<?php echo $this->Webmodel->getLogo() ;?>" style="width: 95px; height: 90px; margin-top: -22px;" alt="Logo">
								</a>
							</div>-->
							<div class="col-md-12">
								<a href="#"><img class="header-banner img-responsive" src="<?php echo base_url('assets/frontend/img/banners/adds.jpg');?>" alt=""></a>
							</div>
						</div>
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
							<span class="full-width-menu">Menu Bar</span>
							<span class="icon-toggle">
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</span>
						</button>
					</div>
				</div>

				<div class="clearfix"></div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse navbar-responsive-collapse">
					<div class="container">
						<ul class="nav navbar-nav">
							<li><a href="<?php echo base_url();?>">Home</a></li>
                            <li><a href="<?php echo base_url('web/page/about-us');?>">About us</a></li>
							<li class="dropdown">
								<a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown">
									Gallery
								</a>
								<ul class="dropdown-menu">
									<li><a href="<?php echo base_url('web/showImageCategory');?>">Images</a></li>
                                    <li><a href="<?php echo base_url('web/showVidCategory');?>">Videos</a></li>
                                    <li><a href="<?php echo base_url('web/showYoutubeCategory');?>">You Tube Video</a></li>
                                    <li><a href="<?php echo base_url('web/showAudioCategory');?>">Songs</a></li>
							
								</ul>
							</li>
                            <li><a href="<?php echo base_url('web/showBookCategory');?>">Books</a></li>
							<li><a href="<?php echo base_url();?>">Services</a></li>
							<li><a href="<?php echo base_url();?>">Explore</a></li>
                            <li><a href="<?php echo base_url();?>">Send News</a></li>
                            <li><a href="<?php echo base_url();?>">Article</a></li>
                            <li><a href="<?php echo base_url();?>">Forum</a></li>
                            
                            <li><a href="<?php echo base_url('web/contact');?>">Contact us</a></li>
							
						</ul>

						<!-- Search Block 
						<ul class="nav navbar-nav navbar-border-bottom navbar-right">
							<li class="no-border">
								<i class="search fa fa-search search-btn"></i>
								<div class="search-open">
									<div class="input-group animated fadeInDown">
										<input type="text" class="form-control" placeholder="Search">
										<span class="input-group-btn">
											<button class="btn-u" type="button">Go</button>
										</span>
									</div>
								</div>
							</li>
						</ul>
						End Search Block -->
					</div><!--/end container-->
				</div><!--/navbar-collapse-->
			</div>
			<!-- End Navbar -->
		</div>
		<!--=== End Header v4 ===-->