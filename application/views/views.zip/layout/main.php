<?php $setting = $this->Pagemodel->getsetting();?>

<?php $this->load->view('layout/header', array('setting'=>$setting)); ?>
<?php $this->load->view($content, array('setting'=>$setting)); ?>
<?php $this->load->view('layout/footer', array('setting'=>$setting));?>




